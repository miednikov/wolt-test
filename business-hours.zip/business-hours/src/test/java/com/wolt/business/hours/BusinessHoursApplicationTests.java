package com.wolt.business.hours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessHoursApplicationTests {

	@Test
	void contextLoads() {
	}

}
