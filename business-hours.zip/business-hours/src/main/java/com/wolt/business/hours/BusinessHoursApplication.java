package com.wolt.business.hours;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessHoursApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessHoursApplication.class, args);
	}

}
