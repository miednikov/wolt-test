package com.wolt.business.hours.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.wolt.business.hours.api.model.BusinessHoursRequest;
import com.wolt.business.hours.service.exception.ValidationException;
import com.wolt.business.hours.test.utils.JsonLoader;

public class BusinessHoursDtoFactoryTest {

    @Test
    public void shouldFailToCreateDtoIfRestaurantOpenedButNeverClosed() {
        BusinessHoursRequest request = JsonLoader.load("invalid/opened_but_never_closed.json", BusinessHoursRequest.class);
        assertThrows(ValidationException.class, () -> {
            BusinessHoursDtoFactory.create(request);
        });
    }

    @Test
    public void shouldFailToCreateDtoIfOverlappingIntervalExists() {
        BusinessHoursRequest request = JsonLoader.load("invalid/overlapping_interval.json", BusinessHoursRequest.class);
        assertThrows(ValidationException.class, () -> {
            BusinessHoursDtoFactory.create(request);
        });
    }

    @Test
    public void shouldFailToCreateDtoIfOpenedAndClosedInWrongOrder() {
        BusinessHoursRequest request = JsonLoader.load("invalid/invalid_order.json", BusinessHoursRequest.class);
        assertThrows(ValidationException.class, () -> {
            BusinessHoursDtoFactory.create(request);
        });
    }

    @Test
    public void shouldFailToCreateDtoIfRestaurantTriedToOpenTwice() {
        BusinessHoursRequest request = JsonLoader.load("invalid/opened_twice.json", BusinessHoursRequest.class);
        assertThrows(ValidationException.class, () -> {
            BusinessHoursDtoFactory.create(request);
        });
    }

    @Test
    public void shouldFailToCreateDtoIfRestaurantTriedToCloseTwice() {
        BusinessHoursRequest request = JsonLoader.load("invalid/closed_twice.json", BusinessHoursRequest.class);
        assertThrows(ValidationException.class, () -> {
            BusinessHoursDtoFactory.create(request);
        });
    }

    @Test
    public void shouldFailToCreateDtoWhenRestaurantClosedInOneDay() {
        BusinessHoursRequest request = JsonLoader.load("invalid/closed_in_a_day.json", BusinessHoursRequest.class);
        assertThrows(ValidationException.class, () -> {
            BusinessHoursDtoFactory.create(request);
        });
    }

    @Test
    public void shouldCreateDtoWhenRestaurantClosedOnNextDay() {
        BusinessHoursRequest request = JsonLoader.load("valid/opened_and_closed_next_day.json", BusinessHoursRequest.class);
        BusinessHoursDto dto = BusinessHoursDtoFactory.create(request);
        List<BusinessHoursRange> businessHoursRanges = dto.getBusinessHoursForDay(DayOfWeek.MONDAY);
        assertEquals(1, businessHoursRanges.size());
        BusinessHoursRange range = businessHoursRanges.get(0);
        assertEquals(LocalTime.parse("12:00"), range.open());
        assertEquals(LocalTime.parse("01:00"), range.closed());
    }

    @Test
    public void shouldCreateDtoWithMultipleSpans() {
        BusinessHoursRequest request = JsonLoader.load("valid/multiple_spans_during_2_days.json", BusinessHoursRequest.class);
        BusinessHoursDto dto = BusinessHoursDtoFactory.create(request);
        List<BusinessHoursRange> fridayRanges = dto.getBusinessHoursForDay(DayOfWeek.FRIDAY);
        assertEquals(1, fridayRanges.size());
        BusinessHoursRange fridayRange = fridayRanges.get(0);
        assertEquals(LocalTime.parse("18:00"), fridayRange.open());
        assertEquals(LocalTime.parse("01:00"), fridayRange.closed());
        List<BusinessHoursRange> saturdayRanges = dto.getBusinessHoursForDay(DayOfWeek.SATURDAY);
        assertEquals(2, saturdayRanges.size());
        BusinessHoursRange saturdayMorningRange = saturdayRanges.get(0);
        assertEquals(LocalTime.parse("09:00"), saturdayMorningRange.open());
        assertEquals(LocalTime.parse("11:00"), saturdayMorningRange.closed());
        BusinessHoursRange saturdayEveningRange = saturdayRanges.get(1);
        assertEquals(LocalTime.parse("16:00"), saturdayEveningRange.open());
        assertEquals(LocalTime.parse("23:00"), saturdayEveningRange.closed());
    }
}
