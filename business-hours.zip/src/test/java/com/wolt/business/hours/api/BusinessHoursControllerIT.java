package com.wolt.business.hours.api;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.wolt.business.hours.test.utils.SampleUtils;

@SpringBootTest
@AutoConfigureMockMvc
public class BusinessHoursControllerIT {

    private static final String URL = "/v1/restaurants/business_hours";

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void shouldValidateRequestAndReturnFormattedSchedule() throws Exception {
        String requestStr = SampleUtils.loadFile("valid/full-time_restaurant.json");

        sendRequest(requestStr)
            .andExpect(status().isOk())
            .andExpect(content().string(equalTo(
               """
               Monday: Closed
               Tuesday: 10 AM - 6 PM
               Wednesday: Closed
               Thursday: 10:30 AM - 6 PM
               Friday: 10 AM - 1 AM
               Saturday: 10 AM - 1 AM
               Sunday: 12 PM - 9 PM
               """
            )));
    }

    @Test
    public void shouldValidateRequestAndReturnErrorDueToRequestValidation() throws Exception {
        String requestStr = SampleUtils.loadFile("invalid/missing_type_and_value.json");

        sendRequest(requestStr).andExpect(status().isBadRequest());
    }

    @Test
    public void shouldValidateRequestAndReturnErrorDueToLogicValidation() throws Exception {
        String requestStr = SampleUtils.loadFile("invalid/invalid_order.json");

        sendRequest(requestStr).andExpect(status().isBadRequest());
    }

    private ResultActions sendRequest(String body) throws Exception {
        return this.mockMvc.perform(
            post(URL)
            .content(body)
            .contentType(MediaType.APPLICATION_JSON_VALUE)
            .accept(MediaType.TEXT_PLAIN_VALUE));
    }

}
