package com.wolt.business.hours.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.wolt.business.hours.service.model.BusinessHoursDto;
import com.wolt.business.hours.service.model.BusinessHoursRange;
import com.wolt.business.hours.service.model.DayOfWeek;

public class BusinessHoursFormatterTest {

    private BusinessHoursFormatter businessHoursFormatter;

    @BeforeEach
    public void setUp() {
        this.businessHoursFormatter = new BusinessHoursFormatter();
    }

    @Test
    public void shouldFormatClosed() {
        BusinessHoursDto dto = new BusinessHoursDto(Collections.emptyMap());
        String expected = """
            Monday: Closed
            Tuesday: Closed
            Wednesday: Closed
            Thursday: Closed
            Friday: Closed
            Saturday: Closed
            Sunday: Closed
            """;
        assertEquals(expected, businessHoursFormatter.format(dto));
    }

    @Test
    public void shouldFormatDayRange() {
        BusinessHoursRange range = new BusinessHoursRange(LocalTime.parse("12:00"), LocalTime.parse("16:00"));
        BusinessHoursDto dto = new BusinessHoursDto(Collections.singletonMap(DayOfWeek.MONDAY, Collections.singletonList(range)));
        String expected = """
            Monday: 12 PM - 4 PM
            Tuesday: Closed
            Wednesday: Closed
            Thursday: Closed
            Friday: Closed
            Saturday: Closed
            Sunday: Closed
            """;
        assertEquals(expected, businessHoursFormatter.format(dto));
    }

    @Test
    public void shouldFormatSameDayRange() {
        BusinessHoursRange range1 = new BusinessHoursRange(LocalTime.parse("12:00"), LocalTime.parse("16:00"));
        BusinessHoursRange range2 = new BusinessHoursRange(LocalTime.parse("17:00"), LocalTime.parse("21:00"));
        BusinessHoursDto dto = new BusinessHoursDto(Collections.singletonMap(DayOfWeek.MONDAY, Arrays.asList(range1, range2)));
        String expected = """
            Monday: 12 PM - 4 PM, 5 PM - 9 PM
            Tuesday: Closed
            Wednesday: Closed
            Thursday: Closed
            Friday: Closed
            Saturday: Closed
            Sunday: Closed
            """;
        assertEquals(expected, businessHoursFormatter.format(dto));
    }

    @Test
    public void shouldFormatRangeWithMinutes() {
        BusinessHoursRange range = new BusinessHoursRange(LocalTime.parse("12:30"), LocalTime.parse("16:30"));
        BusinessHoursDto dto = new BusinessHoursDto(Collections.singletonMap(DayOfWeek.MONDAY, Collections.singletonList(range)));
        String expected = """
            Monday: 12:30 PM - 4:30 PM
            Tuesday: Closed
            Wednesday: Closed
            Thursday: Closed
            Friday: Closed
            Saturday: Closed
            Sunday: Closed
            """;
        assertEquals(expected, businessHoursFormatter.format(dto));
    }
}
