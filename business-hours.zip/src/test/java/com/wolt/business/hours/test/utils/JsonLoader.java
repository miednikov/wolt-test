package com.wolt.business.hours.test.utils;

import java.io.IOException;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class JsonLoader {

    private JsonLoader() {

    }

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static {
        MAPPER.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
    }

    public static <T> T load(String path, Class<T> valueType) {
        try {
            return MAPPER.readValue(SampleUtils.loadFile(path), valueType);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
