package com.wolt.business.hours.test.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.springframework.util.ResourceUtils;

public class SampleUtils {
    private SampleUtils() {
    }

    public static String loadFile(String path) throws IOException {
        File file = ResourceUtils.getFile("classpath:samples/" + path);
        return Files.readString(file.toPath());
    }
}
