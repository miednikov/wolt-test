package com.wolt.business.hours.service.model;

import java.util.Map;

public enum DayOfWeek {

    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;

    private static final Map<DayOfWeek, DayOfWeek> NEXT_DAY_MAPPING = Map.of(
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
        DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
        DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY,
        DayOfWeek.THURSDAY, DayOfWeek.FRIDAY,
        DayOfWeek.FRIDAY, DayOfWeek.SATURDAY,
        DayOfWeek.SATURDAY, DayOfWeek.SUNDAY,
        DayOfWeek.SUNDAY, DayOfWeek.MONDAY
    );

    public DayOfWeek getNextDay() {
        return NEXT_DAY_MAPPING.get(this);
    }
}
