package com.wolt.business.hours.api.model;

import java.util.List;

import javax.validation.Valid;

public record BusinessHoursRequest(
    @Valid List<BusinessHourInfo> monday,
    @Valid List<BusinessHourInfo> tuesday,
    @Valid List<BusinessHourInfo> wednesday,
    @Valid List<BusinessHourInfo> thursday,
    @Valid List<BusinessHourInfo> friday,
    @Valid List<BusinessHourInfo> saturday,
    @Valid List<BusinessHourInfo> sunday
) { }
