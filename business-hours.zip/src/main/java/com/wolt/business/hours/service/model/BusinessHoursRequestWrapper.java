package com.wolt.business.hours.service.model;

import java.util.Collections;
import java.util.List;

import com.wolt.business.hours.api.model.BusinessHourInfo;
import com.wolt.business.hours.api.model.BusinessHoursRequest;

public record BusinessHoursRequestWrapper(BusinessHoursRequest request) {

    public List<BusinessHourInfo> fetchByDay(DayOfWeek day) {
        List<BusinessHourInfo> info = switch (day) {
            case MONDAY -> request.monday();
            case TUESDAY -> request.tuesday();
            case WEDNESDAY -> request.wednesday();
            case THURSDAY -> request.thursday();
            case FRIDAY -> request.friday();
            case SATURDAY -> request.saturday();
            case SUNDAY -> request.sunday();
        };
        return info != null ? info : Collections.emptyList();
    }

}
