package com.wolt.business.hours.service;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.StringUtils;

import com.wolt.business.hours.service.model.BusinessHoursDto;
import com.wolt.business.hours.service.model.BusinessHoursRange;
import com.wolt.business.hours.service.model.DayOfWeek;

public class BusinessHoursFormatter {

    private static final DateTimeFormatter LOCAL_TIME_FORMATTER = DateTimeFormatter.ofPattern("h:mm a");
    private static final String RESTAURANT_CLOSED = "Closed";

    public String format(BusinessHoursDto businessHoursDto) {
        StringBuilder sb = new StringBuilder();
        for (DayOfWeek day : DayOfWeek.values()) {
            sb.append(StringUtils.capitalize(day.name().toLowerCase())).append(": ");
            sb.append(format(businessHoursDto.getBusinessHoursForDay(day)));
            sb.append("\n");
        }
        return sb.toString();
    }

    private String format(List<BusinessHoursRange> ranges) {
        if (ranges.isEmpty()) {
            return RESTAURANT_CLOSED;
        } else {
            return ranges.stream().map(this::formatRange).collect(Collectors.joining(", "));
        }
    }

    private String formatRange(BusinessHoursRange range) {
        String formattedRange = LOCAL_TIME_FORMATTER.format(range.open()) + " - " + LOCAL_TIME_FORMATTER.format(range.closed());
        return formattedRange.replace(":00", "");
    }
}
