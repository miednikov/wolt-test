package com.wolt.business.hours.api.commons;

import java.io.IOException;
import java.time.LocalTime;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class LocalTimeDeserializer extends JsonDeserializer<LocalTime> {

    @Override
    public LocalTime deserialize(JsonParser parser, DeserializationContext context)
            throws IOException {
        String unixTimestamp = parser.getText();
        return !unixTimestamp.isBlank() ? LocalTime.ofSecondOfDay(Long.parseLong(unixTimestamp)) : null;
    }
}