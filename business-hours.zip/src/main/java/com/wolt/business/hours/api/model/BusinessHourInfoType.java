package com.wolt.business.hours.api.model;

public enum BusinessHourInfoType {
    OPEN, CLOSE;
}
