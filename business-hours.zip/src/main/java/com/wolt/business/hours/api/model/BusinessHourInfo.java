package com.wolt.business.hours.api.model;

import java.time.LocalTime;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.wolt.business.hours.api.commons.LocalTimeDeserializer;

public record BusinessHourInfo(
    @NotNull BusinessHourInfoType type,
    @NotNull @JsonDeserialize(using = LocalTimeDeserializer.class) LocalTime value
) { }
