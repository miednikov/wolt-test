package com.wolt.business.hours.service.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public record BusinessHoursDto(Map<DayOfWeek, List<BusinessHoursRange>> info) {

    public List<BusinessHoursRange> getBusinessHoursForDay(DayOfWeek day) {
        return info.getOrDefault(day, Collections.emptyList());
    }

}
