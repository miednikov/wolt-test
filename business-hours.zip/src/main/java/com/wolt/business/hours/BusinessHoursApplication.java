package com.wolt.business.hours;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.wolt.business.hours.service.BusinessHoursFormatter;

@SpringBootApplication
public class BusinessHoursApplication {

    public static void main(String[] args) {
        SpringApplication.run(BusinessHoursApplication.class, args);
    }

    @Bean
    public BusinessHoursFormatter businessHoursFormatter() {
        return new BusinessHoursFormatter();
    }

}
