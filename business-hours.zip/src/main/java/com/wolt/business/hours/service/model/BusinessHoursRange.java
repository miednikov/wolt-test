package com.wolt.business.hours.service.model;

import java.time.LocalTime;

public record BusinessHoursRange(LocalTime open, LocalTime closed) { }
