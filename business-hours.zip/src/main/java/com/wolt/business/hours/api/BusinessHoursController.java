package com.wolt.business.hours.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wolt.business.hours.api.model.BusinessHoursRequest;
import com.wolt.business.hours.service.BusinessHoursFormatter;
import com.wolt.business.hours.service.model.BusinessHoursDto;
import com.wolt.business.hours.service.model.BusinessHoursDtoFactory;

@RestController
@RequestMapping("/v1/restaurants/business_hours")
public class BusinessHoursController {

    private final BusinessHoursFormatter businessHoursFormatter;

    @Autowired
    public BusinessHoursController(BusinessHoursFormatter businessHoursFormatter) {
        this.businessHoursFormatter = businessHoursFormatter;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.TEXT_PLAIN_VALUE)
    public String format(@RequestBody @Valid BusinessHoursRequest request) {
        BusinessHoursDto businessHoursDto = BusinessHoursDtoFactory.create(request);
        return businessHoursFormatter.format(businessHoursDto);
    }
}
