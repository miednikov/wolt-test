package com.wolt.business.hours.service.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import com.wolt.business.hours.api.model.BusinessHourInfo;
import com.wolt.business.hours.api.model.BusinessHourInfoType;
import com.wolt.business.hours.api.model.BusinessHoursRequest;
import com.wolt.business.hours.service.exception.ValidationException;

public class BusinessHoursDtoFactory {

    private BusinessHoursDtoFactory() {
    }

    public static BusinessHoursDto create(BusinessHoursRequest businessHoursRequest) {
        Map<DayOfWeek, List<BusinessHoursRange>> data = new HashMap<>();
        BusinessHoursRequestWrapper businessHoursRequestWrapper = new BusinessHoursRequestWrapper(businessHoursRequest);
        int total = 0;
        for (DayOfWeek day : DayOfWeek.values()) {
            Pair pair = convert(day, businessHoursRequestWrapper);
            total += pair.balance();
            if (!pair.ranges.isEmpty()) {
                data.put(day, pair.ranges());
            }
        }
        if (total != 0) {
            throw new ValidationException("Invalid intervals found");
        }
        return new BusinessHoursDto(data);
    }

    private static Pair convert(DayOfWeek current, BusinessHoursRequestWrapper businessHoursRequest) {
        List<BusinessHoursRange> ranges = new ArrayList<>();
        Stack<BusinessHourInfo> stack = new Stack<>();
        List<BusinessHourInfo> businessHourInfoList = businessHoursRequest.fetchByDay(current);
        int balance = 0;
        for (BusinessHourInfo businessHourInfo : businessHourInfoList) {
            if (businessHourInfo.type().equals(BusinessHourInfoType.OPEN)) {
                stack.push(businessHourInfo);
                balance++;
            } else {
                if (!stack.isEmpty()) {
                    BusinessHourInfo openInfo = stack.pop();
                    ranges.add(new BusinessHoursRange(openInfo.value(), businessHourInfo.value()));
                }
                balance--;
            }
        }
        if (stack.size() == 1) {
            DayOfWeek next = current.getNextDay();
            List<BusinessHourInfo> nextDayInfos = businessHoursRequest.fetchByDay(next);
            if (nextDayInfos.isEmpty()) {
                throw new ValidationException("Restaurant is not closed on the next day");
            }
            BusinessHourInfo info = nextDayInfos.get(0);
            if (info.type().equals(BusinessHourInfoType.OPEN)) {
                throw new ValidationException("Invalid intervals found");
            }
            ranges.add(new BusinessHoursRange(stack.pop().value(), info.value()));
        } else if (stack.size() > 1) {
            throw new ValidationException("Invalid intervals found");
        }
        return new Pair(balance, ranges);
    }

    private record Pair(int balance, List<BusinessHoursRange> ranges) {}
}
