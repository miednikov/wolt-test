Business hours
=========================================================================

REST API which accepts JSON-formatted opening hours of a
restaurant as an input and returns the rendered human readable format as a text output.

## Java version

This project is built on top of java 17.

You can use https://sdkman.io in order to use multiple java versions.

## Run 

Execute command

```
./mvnw spring-boot:run
```

## Linter
If you are using IntelliJ IDEA to work on this project ensure to install the checkstyle plugin:
```
1. Open IntelliJ IDEA from the top menu bar -> Preferences
2. Go to Plugins tab search Checkstyle-IDEA
3. Install the plugin
```

Configure the Editor's code style by importing the scheme:
```
1. Open IntelliJ IDEA from the top menu bar -> Preferences
2. Go to Editor -> Code Style
3. In Scheme, click the gear icon -> Import Scheme -> CheckStyle Configuration
4. Open the configuration file located in: config/checkstyle-config.xml
5. Press OK to finish the configuration 
```

Note: Failure to properly set up the code style scheme may cause builds to fail.

## Nice to have things

Ideally if it would be production service we will need to add to this repo following things:
- Swagger generator
- CI/CD config
- Logging/Monitoring/Tracing libraries

## Decisions regarding corner cases

API will fail if:
- Overlapping open-close intervals exists
- Given open/close objects are in wrong order
- Restaurant didn't close on next day

API doesn't cover 24h scenario.

## Input format notes

Generally speaking format is good enough to cover our needs, but we need to understand limitations of it, if we want to evolve it further:

1. We rely here on the order of objects in json. So either we should force clients to send it in right order or sort objects on consumer side for each day.

2. Here we use UNIX time which sometimes hard to debug since you need to convert it to human-readable format in order to understand what's going on. 
   And it turned out that jackson cannot convert it by default, so I had to write a bit of custom logic for it. 
   Which leads me to idea that it might happen as well outside java/jackson world.
   
3. It might be good idea to wrap days objects to a root object starting from V1 version of the API. 
   Since if we would need additional attributes in a body, and those are not related to days, we will need to change the structure, and it will a breaking change for clients, so it will be harder for them to migrate.

4. Current format is not explicit enough, so every consumer should read a doc regarding how to work with it. 
   So maybe we can rework it in a way where we will have one object for every open -close time range even in the case of the closing time being after midnight and therefore technically on the following day